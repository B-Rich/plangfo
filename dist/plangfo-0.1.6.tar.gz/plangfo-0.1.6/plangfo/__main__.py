if __name__ == "__main__":
	from plangfo import *
	main()